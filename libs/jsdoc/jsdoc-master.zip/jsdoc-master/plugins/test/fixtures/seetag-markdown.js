/**
*  @see [Nowhere](http://nowhere.com)
*/
function foo() {
}

/**
*  @see AnObject#myProperty
*/
function bar() {
}
