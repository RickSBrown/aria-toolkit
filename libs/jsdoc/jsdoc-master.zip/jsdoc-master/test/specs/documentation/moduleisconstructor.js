/*global describe: true, expect: true, it: true, xdescribe: true */

xdescribe('module that exports a constructor', function() {
    // TODO
});