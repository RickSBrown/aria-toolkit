/**
 * @constructor
 */
var Test = function () {};

/**
 * @param {string, number} a
 */
Test.prototype.test = function (a) {};
