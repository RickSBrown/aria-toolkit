/** document me */
var position = {
    axis: {
        /** document me */
        x: 0,
        y: 0
    }
};