/**
    @constructor
 */
function Singer() {

    this.tralala = function() { // method of constructor Singer
        /** document me */
        this.isSinging = true; // setting a member of constructor Singer
    };
}