/**
    Describe the Ticker class here.
    @class
 */
var Ticker = function() {

};

/**
    Describe the NewsSource class here.
    @class NewsSource
 */
