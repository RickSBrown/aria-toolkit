/*!*
* Script that does something awesome
*
* @copyright (c) 2011 Rotorz Limited. All rights reserved.
* @author Lea Hayes
* @module myscript/core
*/

/*!*********************************
 * This should be ignored by JSDoc
 * @var x
 */